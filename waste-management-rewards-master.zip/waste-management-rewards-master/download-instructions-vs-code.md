# Download Instructions for Waste Management Rewards Project

## Step 1: Create the Project Directory Structure

First, create a proper directory structure for your project:

1. Create a main project folder named `waste-management-rewards` on your desktop or preferred location
2. Inside this folder, create the following subdirectories:
   ```
   waste-management-rewards/
   ├── src/
   │   ├── components/
   │   ├── data/
   │   ├── models/
   │   ├── types/
   │   └── utils/
   ```

## Step 2: Download Each File to the Correct Location

### Root Directory Files
Save these files directly in the `waste-management-rewards` folder:

- `package.json`
- `package-lock.json` (will be generated when you run npm install)
- `tsconfig.json`
- `tsconfig.app.json`
- `tsconfig.node.json`
- `vite.config.ts`
- `eslint.config.js`
- `postcss.config.js`
- `tailwind.config.js`
- `index.html`

### Source Files
Save these files in the `src` folder:

- `src/index.css`
- `src/main.tsx`
- `src/App.tsx`
- `src/vite-env.d.ts`

### Component Files
Save these files in the `src/components` folder:

- `src/components/DateFilter.tsx`
- `src/components/HistoricalDataTable.tsx`
- `src/components/TimeSeriesCharts.tsx`
- `src/components/WasteInputForm.tsx`
- `src/components/RewardDistribution.tsx`
- `src/components/FuturePredictions.tsx`
- `src/components/QuickAddWaste.tsx`
- `src/components/ModelAccuracyDisplay.tsx`

### Data Files
Save these files in the `src/data` folder:

- `src/data/sampleData.ts`

### Model Files
Save these files in the `src/models` folder:

- `src/models/RandomForestModel.ts`

### Type Definition Files
Save these files in the `src/types` folder:

- `src/types/waste.ts`

### Utility Files
Save these files in the `src/utils` folder:

- `src/utils/dateUtils.ts`
- `src/utils/timeSeriesUtils.ts`

## Step 3: Verify File Structure

After downloading all files, your project structure should look like this:

```
waste-management-rewards/
├── index.html
├── package.json
├── tsconfig.json
├── tsconfig.app.json
├── tsconfig.node.json
├── vite.config.ts
├── eslint.config.js
├── postcss.config.js
├── tailwind.config.js
├── src/
│   ├── index.css
│   ├── main.tsx
│   ├── App.tsx
│   ├── vite-env.d.ts
│   ├── components/
│   │   ├── DateFilter.tsx
│   │   ├── HistoricalDataTable.tsx
│   │   ├── TimeSeriesCharts.tsx
│   │   ├── WasteInputForm.tsx
│   │   ├── RewardDistribution.tsx
│   │   ├── FuturePredictions.tsx
│   │   ├── QuickAddWaste.tsx
│   │   └── ModelAccuracyDisplay.tsx
│   ├── data/
│   │   └── sampleData.ts
│   ├── models/
│   │   └── RandomForestModel.ts
│   ├── types/
│   │   └── waste.ts
│   └── utils/
│       ├── dateUtils.ts
│       └── timeSeriesUtils.ts
```

## Step 4: Run the Project

1. Open VS Code
2. Choose "File > Open Folder" and select your `waste-management-rewards` folder
3. Open a terminal in VS Code (Terminal > New Terminal)
4. Run the following commands:

```bash
npm install
npm run dev
```

## Troubleshooting Common Issues

### "package.json not found" Error
If you see this error, it means you're running npm commands in the wrong directory. Make sure:
- You've downloaded the package.json file to your project root
- Your terminal is open to the correct project directory
- You're not in a subdirectory of your project

### Checking Your Current Directory
In the terminal, you can check your current directory with:
- Windows: `cd`
- Mac/Linux: `pwd`

Make sure it shows the path to your project root where package.json is located.

### Missing Dependencies
If you encounter errors about missing dependencies, make sure your package.json file is correctly downloaded and run `npm install` again.

### Port Already in Use
If you see an error that the port is already in use, you can either:
- Close the other application using that port
- Modify the vite.config.ts file to use a different port