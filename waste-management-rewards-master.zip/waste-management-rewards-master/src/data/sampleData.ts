import { ExtendedWasteData } from '../types/waste';
import { getWeekNumber } from '../utils/dateUtils';

// Generate 3 years of weekly data (156 weeks)
function generateThreeYearData(): ExtendedWasteData[] {
  const startDate = new Date(2021, 0, 1);
  const data: ExtendedWasteData[] = [];

  // Seasonal factors (multipliers for each season)
  const seasonalFactors = {
    winter: { bio: 0.8, recyclable: 1.2, nonRecyclable: 1.1 }, // Holiday season
    spring: { bio: 1.2, recyclable: 1.0, nonRecyclable: 0.9 }, // Spring cleaning
    summer: { bio: 1.3, recyclable: 0.9, nonRecyclable: 0.8 }, // More garden waste
    fall: { bio: 1.1, recyclable: 1.1, nonRecyclable: 1.0 }    // Fall cleanup
  };

  // Base values for different household sizes
  const householdBaseValues = {
    1: { bio: 2.0, recyclable: 1.5, nonRecyclable: 1.0 },
    2: { bio: 3.5, recyclable: 2.5, nonRecyclable: 1.5 },
    3: { bio: 4.5, recyclable: 3.5, nonRecyclable: 2.0 },
    4: { bio: 5.5, recyclable: 4.5, nonRecyclable: 2.5 },
    5: { bio: 6.5, recyclable: 5.5, nonRecyclable: 3.0 }
  };

  // Generate data for each week
  for (let week = 0; week < 156; week++) {
    const currentDate = new Date(startDate);
    currentDate.setDate(currentDate.getDate() + week * 7);
    
    // Determine season
    const month = currentDate.getMonth();
    const season = 
      month <= 1 || month === 11 ? 'winter' :
      month >= 2 && month <= 4 ? 'spring' :
      month >= 5 && month <= 7 ? 'summer' : 'fall';
    
    // Random household characteristics
    const householdSize = Math.floor(Math.random() * 5) + 1;
    const hasGarden = Math.random() > 0.4; // 60% chance of having a garden
    const incomeLevel = Math.floor(Math.random() * 5) + 1;
    
    // Base waste values for this household
    const baseValues = householdBaseValues[householdSize as keyof typeof householdBaseValues];
    
    // Apply seasonal factors and random variation
    const randomVariation = () => 0.8 + Math.random() * 0.4; // ±20% random variation
    const gardenFactor = hasGarden ? 1.2 : 1.0;
    
    const bioWaste = Number((
      baseValues.bio * 
      seasonalFactors[season].bio * 
      gardenFactor * 
      randomVariation()
    ).toFixed(2));
    
    const recyclableWaste = Number((
      baseValues.recyclable * 
      seasonalFactors[season].recyclable * 
      (incomeLevel / 3) * // Higher income = more recyclables
      randomVariation()
    ).toFixed(2));
    
    const nonRecyclableWaste = Number((
      baseValues.nonRecyclable * 
      seasonalFactors[season].nonRecyclable * 
      randomVariation()
    ).toFixed(2));

    // Calculate reward using the formula
    const reward = Number(calculateReward({
      bioWaste,
      recyclableWaste,
      nonRecyclableWaste
    }).toFixed(2));

    data.push({
      bioWaste,
      recyclableWaste,
      nonRecyclableWaste,
      householdSize,
      hasGarden,
      incomeLevel,
      weekNumber: getWeekNumber(currentDate),
      isHolidaySeason: (month === 11 || month === 0), // December and January
      reward,
      date: currentDate.toISOString()
    });
  }

  return data;
}

// Generate 2024 data with improved waste management trends
function generate2024Data(): ExtendedWasteData[] {
  const startDate = new Date(2024, 0, 1);
  const data: ExtendedWasteData[] = [];

  // Seasonal factors (multipliers for each season)
  const seasonalFactors = {
    winter: { bio: 0.85, recyclable: 1.25, nonRecyclable: 0.95 }, // Improved winter habits
    spring: { bio: 1.3, recyclable: 1.1, nonRecyclable: 0.8 }, // Better spring cleaning
    summer: { bio: 1.4, recyclable: 1.0, nonRecyclable: 0.7 }, // More efficient garden waste
    fall: { bio: 1.2, recyclable: 1.15, nonRecyclable: 0.85 }  // Improved fall cleanup
  };

  // Base values for different household sizes - showing improvement in 2024
  const householdBaseValues = {
    1: { bio: 2.2, recyclable: 1.7, nonRecyclable: 0.8 },
    2: { bio: 3.7, recyclable: 2.8, nonRecyclable: 1.2 },
    3: { bio: 4.8, recyclable: 3.8, nonRecyclable: 1.7 },
    4: { bio: 5.8, recyclable: 4.9, nonRecyclable: 2.1 },
    5: { bio: 6.8, recyclable: 5.9, nonRecyclable: 2.5 }
  };

  // Generate data for each week of 2024 (up to current date)
  const currentDate = new Date();
  const weeksIn2024 = Math.min(
    52, // Maximum 52 weeks
    Math.floor((currentDate.getTime() - startDate.getTime()) / (7 * 24 * 60 * 60 * 1000)) + 1
  );
  
  for (let week = 0; week < weeksIn2024; week++) {
    const weekDate = new Date(startDate);
    weekDate.setDate(weekDate.getDate() + week * 7);
    
    // Determine season
    const month = weekDate.getMonth();
    const season = 
      month <= 1 || month === 11 ? 'winter' :
      month >= 2 && month <= 4 ? 'spring' :
      month >= 5 && month <= 7 ? 'summer' : 'fall';
    
    // Random household characteristics
    const householdSize = Math.floor(Math.random() * 5) + 1;
    const hasGarden = Math.random() > 0.4; // 60% chance of having a garden
    const incomeLevel = Math.floor(Math.random() * 5) + 1;
    
    // Base waste values for this household
    const baseValues = householdBaseValues[householdSize as keyof typeof householdBaseValues];
    
    // Apply seasonal factors and random variation
    const randomVariation = () => 0.85 + Math.random() * 0.3; // ±15% random variation (more consistent)
    const gardenFactor = hasGarden ? 1.25 : 1.0;
    
    // Add a gradual improvement trend throughout 2024 (1-5% improvement per month)
    const monthProgress = month + 1; // 1-12
    const improvementFactor = 1 - (monthProgress * 0.004); // 0.4% improvement per month
    
    const bioWaste = Number((
      baseValues.bio * 
      seasonalFactors[season].bio * 
      gardenFactor * 
      randomVariation() *
      improvementFactor
    ).toFixed(2));
    
    const recyclableWaste = Number((
      baseValues.recyclable * 
      seasonalFactors[season].recyclable * 
      (incomeLevel / 3) * // Higher income = more recyclables
      randomVariation() *
      (1 + monthProgress * 0.005) // Increasing recycling trend (0.5% per month)
    ).toFixed(2));
    
    const nonRecyclableWaste = Number((
      baseValues.nonRecyclable * 
      seasonalFactors[season].nonRecyclable * 
      randomVariation() *
      improvementFactor * 0.95 // Additional reduction in non-recyclables
    ).toFixed(2));

    // Calculate reward using the formula
    const reward = Number(calculateReward({
      bioWaste,
      recyclableWaste,
      nonRecyclableWaste
    }).toFixed(2));

    data.push({
      bioWaste,
      recyclableWaste,
      nonRecyclableWaste,
      householdSize,
      hasGarden,
      incomeLevel,
      weekNumber: getWeekNumber(weekDate),
      isHolidaySeason: (month === 11 || month === 0), // December and January
      reward,
      date: weekDate.toISOString()
    });
  }

  return data;
}

function calculateReward(data: { 
  bioWaste: number; 
  recyclableWaste: number; 
  nonRecyclableWaste: number 
}): number {
  const { bioWaste, recyclableWaste, nonRecyclableWaste } = data;
  const term1 = bioWaste * 0.2 * 60;
  const term2 = recyclableWaste * 7;
  const term3 = nonRecyclableWaste * 4;
  const term4 = (bioWaste + recyclableWaste + nonRecyclableWaste) * 2;
  const term5 = bioWaste * 4;
  const term6 = recyclableWaste * 2;
  
  return term1 + term2 - term3 - (term4 + term5 + term6);
}

// Combine historical data with 2024 data
const historicalData = generateThreeYearData();
const data2024 = generate2024Data();
export const sampleWasteData = [...historicalData, ...data2024];