import React, { useState, useEffect } from 'react';
import { HistoricalDataTable } from './components/HistoricalDataTable';
import { TimeSeriesCharts } from './components/TimeSeriesCharts';
import { DateFilter } from './components/DateFilter';
import { WasteInputForm } from './components/WasteInputForm';
import { RewardDistribution } from './components/RewardDistribution';
import { FuturePredictions } from './components/FuturePredictions';
import { sampleWasteData } from './data/sampleData';
import { WasteData, ExtendedWasteData } from './types/waste';
import { BarChart, Recycle, Database, LayoutDashboard, PlusCircle, Award, FileText, BarChart2 } from 'lucide-react';
import { RandomForestModel } from './models/RandomForestModel';

function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'data' | 'input' | 'rewards'>('dashboard');
  const [wasteData, setWasteData] = useState<(WasteData | ExtendedWasteData)[]>([]);
  const [filteredData, setFilteredData] = useState<(WasteData | ExtendedWasteData)[]>([]);
  const [predictedData, setPredictedData] = useState<WasteData[] | null>(null);
  const [isPredicting, setIsPredicting] = useState(false);
  const [isModelTrained, setIsModelTrained] = useState(false);
  const [model] = useState<RandomForestModel>(new RandomForestModel());
  const [modelMetrics, setModelMetrics] = useState<{
    mae: number;
    rmse: number;
    r2: number;
  } | null>(null);

  useEffect(() => {
    // Load sample data
    setWasteData(sampleWasteData);
    setFilteredData(sampleWasteData);
    
    // Check if we have enough data to train the model
    if (sampleWasteData.length > 20) {
      setIsModelTrained(true);
    }
    
    // Check if we have stored metrics
    const storedMetrics = localStorage.getItem('modelMetrics');
    if (storedMetrics) {
      try {
        setModelMetrics(JSON.parse(storedMetrics));
      } catch (e) {
        console.error("Error parsing stored metrics:", e);
      }
    }
  }, []);

  const handleAddWaste = (newWaste: WasteData) => {
    const updatedData = [newWaste, ...wasteData];
    setWasteData(updatedData);
    setFilteredData(updatedData);
    
    // Check if we have enough data to train the model
    if (updatedData.length > 20 && !isModelTrained) {
      setIsModelTrained(true);
    }
  };
  
  const handleRequestPrediction = async () => {
    if (!isModelTrained || isPredicting) return;
    
    setIsPredicting(true);
    
    try {
      // Train the model with historical data
      const metrics = await model.train(wasteData);
      setModelMetrics(metrics);
      
      // Store metrics in localStorage
      if (metrics) {
        localStorage.setItem('modelMetrics', JSON.stringify(metrics));
      }
      
      // Generate predictions for the next year
      const predictions = await model.predictNextYear(wasteData);
      setPredictedData(predictions);
    } catch (error) {
      console.error("Error generating predictions:", error);
    } finally {
      setIsPredicting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Recycle className="h-8 w-8 text-green-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Waste Management Rewards</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex border-b border-gray-200 mb-6 overflow-x-auto">
          <button
            className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'border-b-2 border-green-500 text-green-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('dashboard')}
          >
            <LayoutDashboard className="w-5 h-5 mr-2" />
            Dashboard
          </button>
          <button
            className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
              activeTab === 'data'
                ? 'border-b-2 border-green-500 text-green-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('data')}
          >
            <Database className="w-5 h-5 mr-2" />
            Historical Data
          </button>
          <button
            className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
              activeTab === 'input'
                ? 'border-b-2 border-green-500 text-green-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('input')}
          >
            <PlusCircle className="w-5 h-5 mr-2" />
            Add Waste Record
          </button>
          <button
            className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
              activeTab === 'rewards'
                ? 'border-b-2 border-green-500 text-green-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('rewards')}
          >
            <Award className="w-5 h-5 mr-2" />
            Reward Analysis
          </button>
        </div>

        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-purple-100 text-purple-600">
                    <FileText className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Total Entries</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {wasteData.length}
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-green-100 text-green-600">
                    <BarChart className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Total Bio Waste</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {wasteData.reduce((sum, item) => sum + item.bioWaste, 0).toFixed(2)} kg
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                    <BarChart className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Total Recyclable</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {wasteData.reduce((sum, item) => sum + item.recyclableWaste, 0).toFixed(2)} kg
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-red-100 text-red-600">
                    <BarChart className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Total Non-Recyclable</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {wasteData.reduce((sum, item) => sum + item.nonRecyclableWaste, 0).toFixed(2)} kg
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <BarChart className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Total Rewards</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {wasteData.reduce((sum, item) => sum + item.reward, 0).toFixed(2)} points
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Time Series Charts */}
            <TimeSeriesCharts data={wasteData} />
            
            {/* Future Predictions */}
            <FuturePredictions 
              historicalData={wasteData}
              predictedData={predictedData}
              onRequestPrediction={handleRequestPrediction}
              isModelTrained={isModelTrained}
              isPredicting={isPredicting}
            />
          </div>
        )}

        {/* Historical Data Tab */}
        {activeTab === 'data' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Historical Waste Data</h2>
              <DateFilter data={wasteData} onFilterChange={setFilteredData} />
            </div>
            <HistoricalDataTable data={filteredData} />
          </div>
        )}

        {/* Input Tab */}
        {activeTab === 'input' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold">Add New Waste Record</h2>
            <WasteInputForm onAddWaste={handleAddWaste} />
          </div>
        )}

        {/* Rewards Tab */}
        {activeTab === 'rewards' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold">Reward Distribution</h2>
            <RewardDistribution data={wasteData} />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-gray-500 text-sm">
            © 2025 Waste Management Rewards System. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;