export interface ExtendedWasteData {
  bioWaste: number;
  recyclableWaste: number;
  nonRecyclableWaste: number;
  householdSize: number;
  hasGarden: boolean;
  incomeLevel: number;
  weekNumber: number;
  isHolidaySeason: boolean;
  reward: number;
  date: string;
}

export interface WasteData {
  bioWaste: number;
  recyclableWaste: number;
  nonRecyclableWaste: number;
  date: string;
  reward: number;
}