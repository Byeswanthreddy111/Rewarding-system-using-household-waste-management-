import { WasteData, ExtendedWasteData } from '../types/waste';

export interface AggregatedData {
  period: string;
  avgBioWaste: number;
  avgRecyclableWaste: number;
  avgNonRecyclableWaste: number;
  totalReward: number;
  count: number;
}

export function aggregateByMonth(data: (WasteData | ExtendedWasteData)[]): AggregatedData[] {
  const aggregated = new Map<string, AggregatedData>();

  data.forEach(entry => {
    const date = new Date(entry.date);
    const period = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;

    if (!aggregated.has(period)) {
      aggregated.set(period, {
        period,
        avgBioWaste: 0,
        avgRecyclableWaste: 0,
        avgNonRecyclableWaste: 0,
        totalReward: 0,
        count: 0
      });
    }

    const current = aggregated.get(period)!;
    current.avgBioWaste += entry.bioWaste;
    current.avgRecyclableWaste += entry.recyclableWaste;
    current.avgNonRecyclableWaste += entry.nonRecyclableWaste;
    current.totalReward += entry.reward;
    current.count++;
  });

  // Calculate averages
  return Array.from(aggregated.values())
    .map(entry => ({
      ...entry,
      avgBioWaste: Number((entry.avgBioWaste / entry.count).toFixed(2)),
      avgRecyclableWaste: Number((entry.avgRecyclableWaste / entry.count).toFixed(2)),
      avgNonRecyclableWaste: Number((entry.avgNonRecyclableWaste / entry.count).toFixed(2)),
      totalReward: Number(entry.totalReward.toFixed(2))
    }))
    .sort((a, b) => a.period.localeCompare(b.period));
}

export function aggregateByYear(data: (WasteData | ExtendedWasteData)[]): AggregatedData[] {
  const aggregated = new Map<string, AggregatedData>();

  data.forEach(entry => {
    const year = new Date(entry.date).getFullYear().toString();

    if (!aggregated.has(year)) {
      aggregated.set(year, {
        period: year,
        avgBioWaste: 0,
        avgRecyclableWaste: 0,
        avgNonRecyclableWaste: 0,
        totalReward: 0,
        count: 0
      });
    }

    const current = aggregated.get(year)!;
    current.avgBioWaste += entry.bioWaste;
    current.avgRecyclableWaste += entry.recyclableWaste;
    current.avgNonRecyclableWaste += entry.nonRecyclableWaste;
    current.totalReward += entry.reward;
    current.count++;
  });

  // Calculate averages
  return Array.from(aggregated.values())
    .map(entry => ({
      ...entry,
      avgBioWaste: Number((entry.avgBioWaste / entry.count).toFixed(2)),
      avgRecyclableWaste: Number((entry.avgRecyclableWaste / entry.count).toFixed(2)),
      avgNonRecyclableWaste: Number((entry.avgNonRecyclableWaste / entry.count).toFixed(2)),
      totalReward: Number(entry.totalReward.toFixed(2))
    }))
    .sort((a, b) => a.period.localeCompare(b.period));
}