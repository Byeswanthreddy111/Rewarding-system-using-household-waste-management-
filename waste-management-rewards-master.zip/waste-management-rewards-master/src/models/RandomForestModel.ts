import * as tf from '@tensorflow/tfjs';
import { ExtendedWasteData, WasteData } from '../types/waste';
import { getWeekNumber } from '../utils/dateUtils';

export class RandomForestModel {
  private trainingStatus: 'idle' | 'training' | 'trained' | 'error' = 'idle';
  private trainingProgress = 0;
  private model: tf.LayersModel | null = null;
  private accuracyMetrics: {
    mae: number;
    rmse: number;
    r2: number;
  } | null = null;

  async train(data: (WasteData | ExtendedWasteData)[]) {
    if (data.length < 20) {
      throw new Error("Not enough data to train the model");
    }

    this.trainingStatus = 'training';
    this.trainingProgress = 0;

    try {
      // Prepare data
      const sortedData = [...data].sort((a, b) => 
        new Date(a.date).getTime() - new Date(b.date).getTime()
      );

      // Extract features and labels
      const features = sortedData.map(item => {
        const date = new Date(item.date);
        return [
          item.bioWaste,
          item.recyclableWaste,
          item.nonRecyclableWaste,
          date.getMonth(), // Month as a feature (0-11)
          Math.sin(2 * Math.PI * date.getMonth() / 12), // Seasonal sine component
          Math.cos(2 * Math.PI * date.getMonth() / 12), // Seasonal cosine component
          'householdSize' in item ? item.householdSize : 3, // Default to 3 if not available
          'hasGarden' in item ? (item.hasGarden ? 1 : 0) : 0.5, // Default to 0.5 if not available
          'incomeLevel' in item ? item.incomeLevel : 3, // Default to 3 if not available
        ];
      });

      const labels = sortedData.map(item => [
        item.bioWaste,
        item.recyclableWaste,
        item.nonRecyclableWaste,
        item.reward
      ]);

      // Split data into training and validation sets (80/20 split)
      const splitIndex = Math.floor(features.length * 0.8);
      
      const trainingFeatures = features.slice(0, splitIndex);
      const trainingLabels = labels.slice(0, splitIndex);
      
      const validationFeatures = features.slice(splitIndex);
      const validationLabels = labels.slice(splitIndex);

      // Convert to tensors
      const xs = tf.tensor2d(trainingFeatures);
      const ys = tf.tensor2d(trainingLabels);
      
      const valXs = tf.tensor2d(validationFeatures);
      const valYs = tf.tensor2d(validationLabels);

      // Create and compile model
      this.model = tf.sequential();
      
      // Input layer
      this.model.add(tf.layers.dense({
        inputShape: [trainingFeatures[0].length],
        units: 32,
        activation: 'relu'
      }));
      
      // Hidden layers
      this.model.add(tf.layers.dense({
        units: 16,
        activation: 'relu'
      }));
      
      // Output layer (4 outputs: bioWaste, recyclableWaste, nonRecyclableWaste, reward)
      this.model.add(tf.layers.dense({
        units: 4
      }));
      
      this.model.compile({
        optimizer: tf.train.adam(0.01),
        loss: 'meanSquaredError',
        metrics: ['mae']
      });

      // Train the model
      const epochs = 50;
      await this.model.fit(xs, ys, {
        epochs,
        validationData: [valXs, valYs],
        callbacks: {
          onEpochEnd: (epoch) => {
            this.trainingProgress = Math.floor((epoch + 1) / epochs * 100);
          }
        }
      });

      // Calculate accuracy metrics on validation data
      const predictions = this.model.predict(valXs) as tf.Tensor;
      const predValues = await predictions.array() as number[][];
      const actualValues = await valYs.array() as number[][];
      
      // Calculate MAE, RMSE, and R² for each output
      const errors = [];
      const squaredErrors = [];
      const actualMeans = [0, 0, 0, 0];
      const totalSquaredDeviations = [0, 0, 0, 0];
      
      // Calculate means first
      for (let i = 0; i < actualValues.length; i++) {
        for (let j = 0; j < 4; j++) {
          actualMeans[j] += actualValues[i][j];
        }
      }
      
      for (let j = 0; j < 4; j++) {
        actualMeans[j] /= actualValues.length;
      }
      
      // Calculate errors and deviations
      for (let i = 0; i < predValues.length; i++) {
        const rowErrors = [];
        const rowSquaredErrors = [];
        
        for (let j = 0; j < 4; j++) {
          const error = Math.abs(predValues[i][j] - actualValues[i][j]);
          const squaredError = error * error;
          
          rowErrors.push(error);
          rowSquaredErrors.push(squaredError);
          
          // For R² calculation
          totalSquaredDeviations[j] += Math.pow(actualValues[i][j] - actualMeans[j], 2);
        }
        
        errors.push(rowErrors);
        squaredErrors.push(rowSquaredErrors);
      }
      
      // Calculate final metrics
      const mae = [0, 0, 0, 0];
      const mse = [0, 0, 0, 0];
      const r2 = [0, 0, 0, 0];
      
      for (let i = 0; i < errors.length; i++) {
        for (let j = 0; j < 4; j++) {
          mae[j] += errors[i][j];
          mse[j] += squaredErrors[i][j];
        }
      }
      
      for (let j = 0; j < 4; j++) {
        mae[j] /= errors.length;
        mse[j] /= squaredErrors.length;
        
        // R² = 1 - (SSres / SStot)
        const ssRes = mse[j] * errors.length; // Sum of squared residuals
        r2[j] = 1 - (ssRes / totalSquaredDeviations[j]);
      }
      
      // Store metrics (focusing on reward prediction accuracy)
      this.accuracyMetrics = {
        mae: Number(mae[3].toFixed(2)),
        rmse: Number(Math.sqrt(mse[3]).toFixed(2)),
        r2: Number(r2[3].toFixed(3))
      };
      
      // Clean up tensors
      xs.dispose();
      ys.dispose();
      valXs.dispose();
      valYs.dispose();
      predictions.dispose();
      
      this.trainingStatus = 'trained';
      this.trainingProgress = 100;
      
      return this.accuracyMetrics;
    } catch (error) {
      console.error("Error training model:", error);
      this.trainingStatus = 'error';
      throw error;
    }
  }

  async predictNextYear(historicalData: (WasteData | ExtendedWasteData)[]): Promise<WasteData[]> {
    if (this.trainingStatus !== 'trained' || !this.model) {
      throw new Error("Model not trained yet");
    }

    // Sort data by date
    const sortedData = [...historicalData].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    const nextYearPredictions: WasteData[] = [];
    
    // Get the last date in the dataset
    const lastDate = new Date(sortedData[sortedData.length - 1].date);
    
    // Predict 12 months (one per month)
    for (let month = 1; month <= 12; month++) {
      // Create next date (one month after the last date)
      const nextDate = new Date(lastDate);
      nextDate.setMonth(nextDate.getMonth() + month);
      
      // Get the most recent data point to use as a base for prediction
      const recentData = sortedData[sortedData.length - 1];
      
      // Create feature vector for prediction
      const features = [
        recentData.bioWaste,
        recentData.recyclableWaste,
        recentData.nonRecyclableWaste,
        nextDate.getMonth(),
        Math.sin(2 * Math.PI * nextDate.getMonth() / 12),
        Math.cos(2 * Math.PI * nextDate.getMonth() / 12),
        'householdSize' in recentData ? recentData.householdSize : 3,
        'hasGarden' in recentData ? (recentData.hasGarden ? 1 : 0) : 0.5,
        'incomeLevel' in recentData ? recentData.incomeLevel : 3,
      ];
      
      // Make prediction
      const inputTensor = tf.tensor2d([features]);
      const prediction = this.model.predict(inputTensor) as tf.Tensor;
      const predValues = await prediction.array() as number[][];
      
      // Extract predicted values
      const [bioWaste, recyclableWaste, nonRecyclableWaste, reward] = predValues[0];
      
      // Clean up tensors
      inputTensor.dispose();
      prediction.dispose();
      
      // Add some randomness to make predictions more realistic
      const randomFactor = 0.95 + Math.random() * 0.1; // ±5% random variation
      
      // Create prediction data point
      nextYearPredictions.push({
        bioWaste: Number((bioWaste * randomFactor).toFixed(2)),
        recyclableWaste: Number((recyclableWaste * randomFactor).toFixed(2)),
        nonRecyclableWaste: Number((nonRecyclableWaste * randomFactor).toFixed(2)),
        date: nextDate.toISOString(),
        reward: Number(reward.toFixed(2))
      });
    }
    
    return nextYearPredictions;
  }

  getTrainingStatus() {
    return {
      status: this.trainingStatus,
      progress: this.trainingProgress,
      metrics: this.accuracyMetrics
    };
  }

  private getSeasonalFactor(month: number) {
    // Seasonal factors (multipliers for each season)
    if (month <= 1 || month === 11) { // Winter (Dec-Feb)
      return { bio: 0.8, recyclable: 1.2, nonRecyclable: 1.1 };
    } else if (month >= 2 && month <= 4) { // Spring (Mar-May)
      return { bio: 1.2, recyclable: 1.0, nonRecyclable: 0.9 };
    } else if (month >= 5 && month <= 7) { // Summer (Jun-Aug)
      return { bio: 1.3, recyclable: 0.9, nonRecyclable: 0.8 };
    } else { // Fall (Sep-Nov)
      return { bio: 1.1, recyclable: 1.1, nonRecyclable: 1.0 };
    }
  }

  private calculateReward(bioWaste: number, recyclableWaste: number, nonRecyclableWaste: number): number {
    const term1 = bioWaste * 0.2 * 60;
    const term2 = recyclableWaste * 7;
    const term3 = nonRecyclableWaste * 4;
    const term4 = (bioWaste + recyclableWaste + nonRecyclableWaste) * 2;
    const term5 = bioWaste * 4;
    const term6 = recyclableWaste * 2;
    
    return Number((term1 + term2 - term3 - (term4 + term5 + term6)).toFixed(2));
  }
}