import React, { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { WasteData, ExtendedWasteData } from '../types/waste';
import { aggregateByMonth, aggregateByYear, AggregatedData } from '../utils/timeSeriesUtils';
import { DateFilter } from './DateFilter';

interface TimeSeriesChartsProps {
  data: (WasteData | ExtendedWasteData)[];
}

export function TimeSeriesCharts({ data }: TimeSeriesChartsProps) {
  const [timeframe, setTimeframe] = useState<'monthly' | 'yearly'>('monthly');
  const [filteredData, setFilteredData] = useState<(WasteData | ExtendedWasteData)[]>(data);
  
  const aggregatedData = timeframe === 'monthly' 
    ? aggregateByMonth(filteredData) 
    : aggregateByYear(filteredData);

  const formatTooltipValue = (value: number) => `${value.toFixed(2)} kg`;
  const formatReward = (value: number) => `${value.toFixed(2)} points`;

  // Update filtered data when main data changes
  React.useEffect(() => {
    setFilteredData(data);
  }, [data]);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold mb-6 flex items-center gap-2">
          Time Series Analysis
        </h2>
        <div className="flex gap-4 items-center">
          <DateFilter data={data} onFilterChange={setFilteredData} />
          <div className="flex gap-2">
            <button
              onClick={() => setTimeframe('monthly')}
              className={`px-4 py-2 rounded-lg ${
                timeframe === 'monthly'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setTimeframe('yearly')}
              className={`px-4 py-2 rounded-lg ${
                timeframe === 'yearly'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Yearly
            </button>
          </div>
        </div>
      </div>

      {filteredData.length === 0 ? (
        <div className="bg-white p-6 rounded-xl shadow-lg text-center">
          <p className="text-gray-600">No data available for the selected period.</p>
        </div>
      ) : (
        <div className="grid gap-8">
          {/* Waste Trends */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-medium mb-4">Waste Trends</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={aggregatedData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" />
                  <YAxis />
                  <Tooltip 
                    formatter={formatTooltipValue}
                    labelFormatter={(label) => `Period: ${label}`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="avgBioWaste"
                    name="Bio Waste"
                    stroke="#22c55e"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="avgRecyclableWaste"
                    name="Recyclable Waste"
                    stroke="#3b82f6"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="avgNonRecyclableWaste"
                    name="Non-Recyclable Waste"
                    stroke="#ef4444"
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Rewards Distribution */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-medium mb-4">Rewards Distribution</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={aggregatedData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" />
                  <YAxis />
                  <Tooltip 
                    formatter={formatReward}
                    labelFormatter={(label) => `Period: ${label}`}
                  />
                  <Legend />
                  <Bar
                    dataKey="totalReward"
                    name="Total Reward"
                    fill="#22c55e"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}