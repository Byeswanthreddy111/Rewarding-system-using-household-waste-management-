import React, { useState } from 'react';
import { Calendar, ChevronDown } from 'lucide-react';
import { WasteData, ExtendedWasteData } from '../types/waste';

interface DateFilterProps {
  data: (WasteData | ExtendedWasteData)[];
  onFilterChange: (filteredData: (WasteData | ExtendedWasteData)[]) => void;
}

export function DateFilter({ data, onFilterChange }: DateFilterProps) {
  const [filterType, setFilterType] = useState<'all' | 'date' | 'month' | 'year'>('all');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState<string>('');
  const [isOpen, setIsOpen] = useState(false);

  // Extract unique years and months from data
  const years = [...new Set(data.map(item => new Date(item.date).getFullYear()))].sort((a, b) => b - a);
  
  const months = [
    { value: '01', label: 'January' },
    { value: '02', label: 'February' },
    { value: '03', label: 'March' },
    { value: '04', label: 'April' },
    { value: '05', label: 'May' },
    { value: '06', label: 'June' },
    { value: '07', label: 'July' },
    { value: '08', label: 'August' },
    { value: '09', label: 'September' },
    { value: '10', label: 'October' },
    { value: '11', label: 'November' },
    { value: '12', label: 'December' }
  ];

  const applyFilter = () => {
    let filteredData = [...data];
    
    if (filterType === 'date' && selectedDate) {
      const dateStr = selectedDate.split('T')[0]; // Get just the date part
      filteredData = data.filter(item => item.date.startsWith(dateStr));
    } else if (filterType === 'month' && selectedMonth && selectedYear) {
      const monthStr = `${selectedYear}-${selectedMonth}`;
      filteredData = data.filter(item => item.date.startsWith(monthStr));
    } else if (filterType === 'year' && selectedYear) {
      filteredData = data.filter(item => item.date.startsWith(selectedYear));
    }
    
    onFilterChange(filteredData);
    setIsOpen(false);
  };

  const resetFilter = () => {
    setFilterType('all');
    setSelectedDate('');
    setSelectedMonth('');
    setSelectedYear('');
    onFilterChange(data);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-gray-300 shadow-sm hover:bg-gray-50"
      >
        <Calendar className="w-5 h-5 text-green-600" />
        <span>
          {filterType === 'all' && 'All Data'}
          {filterType === 'date' && `Date: ${new Date(selectedDate).toLocaleDateString()}`}
          {filterType === 'month' && `Month: ${months.find(m => m.value === selectedMonth)?.label} ${selectedYear}`}
          {filterType === 'year' && `Year: ${selectedYear}`}
        </span>
        <ChevronDown className="w-4 h-4" />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-72 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
          <div className="p-4">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Filter Type</label>
              <select 
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="w-full px-3 py-2 rounded-md border border-gray-300"
              >
                <option value="all">All Data</option>
                <option value="date">Specific Date</option>
                <option value="month">Month</option>
                <option value="year">Year</option>
              </select>
            </div>

            {filterType === 'date' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Select Date</label>
                <input 
                  type="date" 
                  value={selectedDate.split('T')[0]}
                  onChange={(e) => setSelectedDate(`${e.target.value}T00:00:00.000Z`)}
                  className="w-full px-3 py-2 rounded-md border border-gray-300"
                />
              </div>
            )}

            {(filterType === 'month' || filterType === 'year') && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Select Year</label>
                <select 
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-gray-300"
                >
                  <option value="">Select Year</option>
                  {years.map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
            )}

            {filterType === 'month' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Select Month</label>
                <select 
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-gray-300"
                >
                  <option value="">Select Month</option>
                  {months.map(month => (
                    <option key={month.value} value={month.value}>{month.label}</option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={applyFilter}
                className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
              >
                Apply
              </button>
              <button
                onClick={resetFilter}
                className="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}