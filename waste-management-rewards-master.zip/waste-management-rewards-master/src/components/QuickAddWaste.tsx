import React, { useState } from 'react';
import { WasteData } from '../types/waste';
import { PlusCircle, Leaf, Recycle, Trash2, Check, X } from 'lucide-react';

interface QuickAddWasteProps {
  onAddWaste: (newWaste: WasteData) => void;
}

export function QuickAddWaste({ onAddWaste }: QuickAddWasteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [bioWaste, setBioWaste] = useState<number>(0);
  const [recyclableWaste, setRecyclableWaste] = useState<number>(0);
  const [nonRecyclableWaste, setNonRecyclableWaste] = useState<number>(0);

  const calculateReward = (bio: number, recyclable: number, nonRecyclable: number): number => {
    const term1 = bio * 0.2 * 60;
    const term2 = recyclable * 7;
    const term3 = nonRecyclable * 4;
    const term4 = (bio + recyclable + nonRecyclable) * 2;
    const term5 = bio * 4;
    const term6 = recyclable * 2;
    
    return Number((term1 + term2 - term3 - (term4 + term5 + term6)).toFixed(2));
  };

  const handleSubmit = () => {
    if (bioWaste === 0 && recyclableWaste === 0 && nonRecyclableWaste === 0) {
      return; // Don't submit if all values are 0
    }
    
    const reward = calculateReward(bioWaste, recyclableWaste, nonRecyclableWaste);
    
    const newWaste: WasteData = {
      bioWaste,
      recyclableWaste,
      nonRecyclableWaste,
      reward,
      date: new Date().toISOString()
    };
    
    onAddWaste(newWaste);
    
    // Reset form and close
    setBioWaste(0);
    setRecyclableWaste(0);
    setNonRecyclableWaste(0);
    setIsOpen(false);
  };

  const handleCancel = () => {
    setBioWaste(0);
    setRecyclableWaste(0);
    setNonRecyclableWaste(0);
    setIsOpen(false);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 relative">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="w-full h-full flex flex-col items-center justify-center gap-2 text-gray-500 hover:text-green-600 transition-colors"
        >
          <PlusCircle className="w-10 h-10" />
          <span className="font-medium">Add Record</span>
        </button>
      ) : (
        <div className="space-y-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Quick Add Waste Record</h3>
          
          <div>
            <label className="flex items-center text-xs font-medium text-gray-600 mb-1">
              <Leaf className="w-3 h-3 text-green-600 mr-1" />
              Bio Waste (kg)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={bioWaste}
              onChange={(e) => setBioWaste(Number(e.target.value))}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            />
          </div>
          
          <div>
            <label className="flex items-center text-xs font-medium text-gray-600 mb-1">
              <Recycle className="w-3 h-3 text-blue-600 mr-1" />
              Recyclable (kg)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={recyclableWaste}
              onChange={(e) => setRecyclableWaste(Number(e.target.value))}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="flex items-center text-xs font-medium text-gray-600 mb-1">
              <Trash2 className="w-3 h-3 text-red-600 mr-1" />
              Non-Recyclable (kg)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={nonRecyclableWaste}
              onChange={(e) => setNonRecyclableWaste(Number(e.target.value))}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500"
            />
          </div>
          
          <div className="flex gap-2 pt-1">
            <button
              onClick={handleCancel}
              className="flex-1 bg-gray-100 text-gray-700 py-1 px-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-1 text-sm"
            >
              <X className="w-3 h-3" />
              Cancel
            </button>
            
            <button
              onClick={handleSubmit}
              className="flex-1 bg-green-600 text-white py-1 px-2 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-1 text-sm"
            >
              <Check className="w-3 h-3" />
              Save
            </button>
          </div>
        </div>
      )}
    </div>
  );
}