import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { WasteData } from '../types/waste';
import { Calendar, TrendingUp, AlertCircle, Loader2, BarChart2 } from 'lucide-react';

interface FuturePredictionsProps {
  historicalData: WasteData[];
  predictedData: WasteData[] | null;
  onRequestPrediction: () => void;
  isModelTrained: boolean;
  isPredicting: boolean;
}

export function FuturePredictions({ 
  historicalData, 
  predictedData, 
  onRequestPrediction,
  isModelTrained,
  isPredicting
}: FuturePredictionsProps) {
  const [chartData, setChartData] = useState<any[]>([]);
  const [yearFilter, setYearFilter] = useState<'all' | 'future'>('all');
  const [modelMetrics, setModelMetrics] = useState<{
    mae: number;
    rmse: number;
    r2: number;
  } | null>(null);

  useEffect(() => {
    // Check if we have model metrics in localStorage
    const storedMetrics = localStorage.getItem('modelMetrics');
    if (storedMetrics) {
      try {
        setModelMetrics(JSON.parse(storedMetrics));
      } catch (e) {
        console.error("Error parsing stored metrics:", e);
      }
    }
  }, []);

  useEffect(() => {
    if (!historicalData.length) return;

    // Prepare data for the chart - use only the last 12 months of historical data
    const sortedHistoricalData = [...historicalData].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    // Get the last 12 months of data
    const lastYear = new Date();
    lastYear.setFullYear(lastYear.getFullYear() - 1);
    
    const recentHistoricalData = sortedHistoricalData.filter(item => 
      new Date(item.date) >= lastYear
    );
    
    // Group by month for better visualization
    const monthlyData: Record<string, any> = {};
    
    // Process historical data
    recentHistoricalData.forEach(item => {
      const date = new Date(item.date);
      const monthYear = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      
      if (!monthlyData[monthYear]) {
        monthlyData[monthYear] = {
          date: monthYear,
          actualBioWaste: 0,
          actualRecyclable: 0,
          actualNonRecyclable: 0,
          actualReward: 0,
          predictedBioWaste: null,
          predictedRecyclable: null,
          predictedNonRecyclable: null,
          predictedReward: null,
          actualCount: 0,
          predictedCount: 0,
          timestamp: date.getTime(),
          year: 'historical'
        };
      }
      
      monthlyData[monthYear].actualBioWaste += item.bioWaste;
      monthlyData[monthYear].actualRecyclable += item.recyclableWaste;
      monthlyData[monthYear].actualNonRecyclable += item.nonRecyclableWaste;
      monthlyData[monthYear].actualReward += item.reward;
      monthlyData[monthYear].actualCount++;
    });
    
    // Process predicted data if available
    if (predictedData && predictedData.length > 0) {
      predictedData.forEach(item => {
        const date = new Date(item.date);
        const monthYear = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        
        if (!monthlyData[monthYear]) {
          monthlyData[monthYear] = {
            date: monthYear,
            actualBioWaste: null,
            actualRecyclable: null,
            actualNonRecyclable: null,
            actualReward: null,
            predictedBioWaste: 0,
            predictedRecyclable: 0,
            predictedNonRecyclable: 0,
            predictedReward: 0,
            actualCount: 0,
            predictedCount: 0,
            timestamp: date.getTime(),
            year: 'future'
          };
        }
        
        monthlyData[monthYear].predictedBioWaste += item.bioWaste;
        monthlyData[monthYear].predictedRecyclable += item.recyclableWaste;
        monthlyData[monthYear].predictedNonRecyclable += item.nonRecyclableWaste;
        monthlyData[monthYear].predictedReward += item.reward;
        monthlyData[monthYear].predictedCount++;
      });
    }
    
    // Calculate averages
    const finalChartData = Object.values(monthlyData).map((item: any) => ({
      date: item.date,
      actualBioWaste: item.actualCount ? Number((item.actualBioWaste / item.actualCount).toFixed(2)) : null,
      actualRecyclable: item.actualCount ? Number((item.actualRecyclable / item.actualCount).toFixed(2)) : null,
      actualNonRecyclable: item.actualCount ? Number((item.actualNonRecyclable / item.actualCount).toFixed(2)) : null,
      actualReward: item.actualCount ? Number((item.actualReward / item.actualCount).toFixed(2)) : null,
      predictedBioWaste: item.predictedCount ? Number((item.predictedBioWaste / item.predictedCount).toFixed(2)) : null,
      predictedRecyclable: item.predictedCount ? Number((item.predictedRecyclable / item.predictedCount).toFixed(2)) : null,
      predictedNonRecyclable: item.predictedCount ? Number((item.predictedNonRecyclable / item.predictedCount).toFixed(2)) : null,
      predictedReward: item.predictedCount ? Number((item.predictedReward / item.predictedCount).toFixed(2)) : null,
      year: item.year
    }));
    
    // Sort by date
    finalChartData.sort((a: any, b: any) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return dateA.getTime() - dateB.getTime();
    });
    
    setChartData(finalChartData);
  }, [historicalData, predictedData]);

  // Filter chart data based on selected year
  const filteredChartData = chartData.filter(item => {
    if (yearFilter === 'all') return true;
    return item.year === yearFilter;
  });

  if (!isModelTrained) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6 mt-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            Future Predictions
          </h2>
        </div>
        
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-medium text-yellow-800">Model Training Required</h3>
            <p className="text-sm text-yellow-700 mt-1">
              The prediction model needs more data to make accurate future predictions. 
              Continue adding waste records to train the model.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mt-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-blue-600" />
          Future Predictions
        </h2>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <label htmlFor="yearFilter" className="text-sm font-medium text-gray-700">
              View:
            </label>
            <select
              id="yearFilter"
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value as any)}
              className="px-3 py-1.5 rounded-md border border-gray-300 text-sm"
            >
              <option value="all">All Data</option>
              {predictedData && predictedData.length > 0 && (
                <option value="future">Future Only</option>
              )}
            </select>
          </div>
          
          <button
            onClick={onRequestPrediction}
            disabled={!isModelTrained || isPredicting}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isPredicting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Predicting...
              </>
            ) : (
              <>
                <Calendar className="w-4 h-4" />
                Predict Next Year
              </>
            )}
          </button>
        </div>
      </div>
      
      {isPredicting ? (
        <div className="h-80 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
            <p className="text-lg font-medium text-gray-700">Generating predictions...</p>
            <p className="text-sm text-gray-500 mt-2">This will only take a moment</p>
          </div>
        </div>
      ) : predictedData === null ? (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-medium text-blue-800">Generate Predictions</h3>
            <p className="text-sm text-blue-700 mt-1">
              Click the "Predict Next Year" button to generate waste and reward predictions for the upcoming year based on your historical data patterns.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Model Accuracy Metrics */}
          {modelMetrics && (
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
              <h3 className="text-lg font-medium mb-3 flex items-center gap-2">
                <BarChart2 className="w-5 h-5 text-blue-600" />
                Model Accuracy Metrics
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white p-3 rounded-md shadow-sm">
                  <p className="text-sm text-gray-500">Mean Absolute Error</p>
                  <p className="text-xl font-semibold text-blue-700">{modelMetrics.mae.toFixed(2)}</p>
                  <p className="text-xs text-gray-500 mt-1">Lower is better</p>
                </div>
                <div className="bg-white p-3 rounded-md shadow-sm">
                  <p className="text-sm text-gray-500">Root Mean Squared Error</p>
                  <p className="text-xl font-semibold text-blue-700">{modelMetrics.rmse.toFixed(2)}</p>
                  <p className="text-xs text-gray-500 mt-1">Lower is better</p>
                </div>
                <div className="bg-white p-3 rounded-md shadow-sm">
                  <p className="text-sm text-gray-500">R² Score</p>
                  <p className="text-xl font-semibold text-blue-700">{modelMetrics.r2.toFixed(3)}</p>
                  <p className="text-xs text-gray-500 mt-1">Closer to 1 is better</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-3">
                These metrics indicate how accurate the model's predictions are likely to be. 
                An R² score close to 1 means the model explains most of the variance in the data.
              </p>
            </div>
          )}

          {/* Reward Predictions */}
          <div>
            <h3 className="text-lg font-medium mb-4">Reward Predictions</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={filteredChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: any) => value !== null ? `${value.toFixed(2)} points` : 'N/A'}
                    labelFormatter={(label) => `Period: ${label}`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="actualReward"
                    name="Actual Rewards"
                    stroke="#22c55e"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="predictedReward"
                    name="Predicted Rewards"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          {/* Waste Predictions */}
          <div>
            <h3 className="text-lg font-medium mb-4">Waste Predictions</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={filteredChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: any) => value !== null ? `${value.toFixed(2)} kg` : 'N/A'}
                    labelFormatter={(label) => `Period: ${label}`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="actualBioWaste"
                    name="Actual Bio Waste"
                    stroke="#22c55e"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="predictedBioWaste"
                    name="Predicted Bio Waste"
                    stroke="#22c55e"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                  <Line
                    type="monotone"
                    dataKey="actualRecyclable"
                    name="Actual Recyclable"
                    stroke="#3b82f6"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="predictedRecyclable"
                    name="Predicted Recyclable"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                  <Line
                    type="monotone"
                    dataKey="actualNonRecyclable"
                    name="Actual Non-Recyclable"
                    stroke="#ef4444"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="predictedNonRecyclable"
                    name="Predicted Non-Recyclable"
                    stroke="#ef4444"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4">
            <h3 className="font-medium text-blue-800 mb-2">Prediction Insights</h3>
            <p className="text-sm text-blue-700">
              These predictions are based on your historical waste patterns and seasonal trends. 
              The dashed lines represent predicted values, while solid lines show your actual historical data.
              The model has been trained using TensorFlow.js with an accuracy of {modelMetrics ? `${(modelMetrics.r2 * 100).toFixed(1)}%` : 'calculating...'} (R² score).
            </p>
          </div>
        </div>
      )}
    </div>
  );
}