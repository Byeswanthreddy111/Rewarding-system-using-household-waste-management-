import React from 'react';
import { BarChart2, TrendingUp, AlertCircle } from 'lucide-react';

interface ModelAccuracyDisplayProps {
  metrics: {
    mae: number;
    rmse: number;
    r2: number;
  } | null;
  isModelTrained: boolean;
}

export function ModelAccuracyDisplay({ metrics, isModelTrained }: ModelAccuracyDisplayProps) {
  if (!isModelTrained) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-medium text-yellow-800">Model Not Trained</h3>
          <p className="text-sm text-yellow-700 mt-1">
            The prediction model needs to be trained before accuracy metrics can be displayed.
            Add more waste records and generate predictions to train the model.
          </p>
        </div>
      </div>
    );
  }

  if (!metrics) {
    return (
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <TrendingUp className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-medium text-blue-800">Model Trained</h3>
          <p className="text-sm text-blue-700 mt-1">
            The prediction model has been trained, but detailed accuracy metrics are not available.
            Generate new predictions to calculate accuracy metrics.
          </p>
        </div>
      </div>
    );
  }

  // Interpret R² score
  let r2Interpretation = '';
  if (metrics.r2 < 0.3) {
    r2Interpretation = 'Poor fit';
  } else if (metrics.r2 < 0.5) {
    r2Interpretation = 'Weak fit';
  } else if (metrics.r2 < 0.7) {
    r2Interpretation = 'Moderate fit';
  } else if (metrics.r2 < 0.9) {
    r2Interpretation = 'Good fit';
  } else {
    r2Interpretation = 'Excellent fit';
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <BarChart2 className="w-6 h-6 text-blue-600" />
        Model Accuracy Metrics
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm font-medium text-gray-600">Mean Absolute Error (MAE)</p>
          <p className="text-2xl font-bold text-blue-700">{metrics.mae.toFixed(2)}</p>
          <p className="text-xs text-gray-500 mt-1">
            Average absolute difference between predicted and actual values
          </p>
        </div>
        
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm font-medium text-gray-600">Root Mean Squared Error (RMSE)</p>
          <p className="text-2xl font-bold text-blue-700">{metrics.rmse.toFixed(2)}</p>
          <p className="text-xs text-gray-500 mt-1">
            Square root of the average squared differences
          </p>
        </div>
        
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm font-medium text-gray-600">R² Score (Coefficient of Determination)</p>
          <p className="text-2xl font-bold text-blue-700">{metrics.r2.toFixed(3)}</p>
          <p className="text-xs text-gray-500 mt-1">
            {r2Interpretation} (1.0 is perfect prediction)
          </p>
        </div>
      </div>

      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="font-medium text-gray-700 mb-2">What These Metrics Mean</h3>
        <ul className="text-sm text-gray-600 space-y-2">
          <li><span className="font-medium">MAE:</span> On average, predictions are off by {metrics.mae.toFixed(2)} points from actual values.</li>
          <li><span className="font-medium">RMSE:</span> Gives higher weight to larger errors. Lower values indicate better fit.</li>
          <li><span className="font-medium">R²:</span> Shows that the model explains {(metrics.r2 * 100).toFixed(1)}% of the variance in the data.</li>
        </ul>
      </div>
    </div>
  );
}