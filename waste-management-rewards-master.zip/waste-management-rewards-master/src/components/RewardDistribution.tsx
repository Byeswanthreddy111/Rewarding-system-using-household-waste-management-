import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { WasteData, ExtendedWasteData } from '../types/waste';
import { Award, TrendingUp, TrendingDown } from 'lucide-react';

interface RewardDistributionProps {
  data: (WasteData | ExtendedWasteData)[];
}

export function RewardDistribution({ data }: RewardDistributionProps) {
  // Filter to only include entries with positive rewards
  const positiveRewardData = data.filter(item => item.reward > 0);
  const negativeRewardData = data.filter(item => item.reward < 0);
  
  // Calculate total rewards
  const totalPositiveRewards = positiveRewardData.reduce((sum, item) => sum + item.reward, 0);
  const totalNegativeRewards = Math.abs(negativeRewardData.reduce((sum, item) => sum + item.reward, 0));
  
  // Calculate average rewards
  const avgPositiveReward = positiveRewardData.length > 0 
    ? totalPositiveRewards / positiveRewardData.length 
    : 0;
  
  const avgNegativeReward = negativeRewardData.length > 0 
    ? totalNegativeRewards / negativeRewardData.length 
    : 0;
  
  // Prepare data for pie chart
  const pieData = [
    { name: 'Bio Waste', value: 0 },
    { name: 'Recyclable Bonus', value: 0 },
    { name: 'Non-Recyclable Penalty', value: 0 },
    { name: 'Total Volume Penalty', value: 0 }
  ];
  
  // Calculate contribution of each factor to the reward
  data.forEach(item => {
    const bioBonus = item.bioWaste * 0.2 * 60;
    const recyclableBonus = item.recyclableWaste * 7;
    const nonRecyclablePenalty = item.nonRecyclableWaste * 4;
    const volumePenalty = (item.bioWaste + item.recyclableWaste + item.nonRecyclableWaste) * 2 +
                          (item.bioWaste * 4) + (item.recyclableWaste * 2);
    
    pieData[0].value += bioBonus;
    pieData[1].value += recyclableBonus;
    pieData[2].value += nonRecyclablePenalty;
    pieData[3].value += volumePenalty;
  });
  
  // Ensure all values are positive for the pie chart
  pieData.forEach(item => {
    item.value = Math.abs(item.value);
  });
  
  // Colors for the pie chart
  const COLORS = ['#22c55e', '#3b82f6', '#ef4444', '#f59e0b'];
  
  // Calculate percentage of positive vs negative rewards
  const totalEntries = data.length;
  const positivePercentage = totalEntries > 0 ? (positiveRewardData.length / totalEntries) * 100 : 0;
  const negativePercentage = totalEntries > 0 ? (negativeRewardData.length / totalEntries) * 100 : 0;
  
  // Custom rendering for pie chart labels to ensure visibility
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = outerRadius * 1.1;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    
    return (
      <text 
        x={x} 
        y={y} 
        fill={COLORS[index % COLORS.length]}
        textAnchor={x > cx ? 'start' : 'end'} 
        dominantBaseline="central"
        fontWeight="bold"
        fontSize="12"
      >
        {`${name}: ${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };
  
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
        <Award className="w-6 h-6 text-yellow-500" />
        Reward Distribution Analysis
      </h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Reward Statistics */}
        <div>
          <h3 className="text-lg font-medium mb-4">Reward Statistics</h3>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-green-50 rounded-lg p-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <p className="text-sm font-medium text-gray-700">Positive Rewards</p>
              </div>
              <p className="text-2xl font-bold text-green-600 mt-1">{positiveRewardData.length}</p>
              <p className="text-sm text-gray-500">
                {positivePercentage.toFixed(1)}% of entries
              </p>
            </div>
            
            <div className="bg-red-50 rounded-lg p-4">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-red-600" />
                <p className="text-sm font-medium text-gray-700">Negative Rewards</p>
              </div>
              <p className="text-2xl font-bold text-red-600 mt-1">{negativeRewardData.length}</p>
              <p className="text-sm text-gray-500">
                {negativePercentage.toFixed(1)}% of entries
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-1">Total Positive Rewards</h4>
              <p className="text-2xl font-bold text-green-600">{totalPositiveRewards.toFixed(2)} points</p>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-1">Average Positive Reward</h4>
              <p className="text-2xl font-bold text-green-600">{avgPositiveReward.toFixed(2)} points</p>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-1">Average Negative Penalty</h4>
              <p className="text-2xl font-bold text-red-600">-{avgNegativeReward.toFixed(2)} points</p>
            </div>
          </div>
        </div>
        
        {/* Reward Composition Pie Chart */}
        <div>
          <h3 className="text-lg font-medium mb-4">Reward Composition</h3>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={renderCustomizedLabel}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `${Number(value).toFixed(2)} points`} />
                <Legend 
                  layout="vertical" 
                  verticalAlign="middle" 
                  align="right"
                  wrapperStyle={{
                    paddingLeft: "20px",
                    fontSize: "12px"
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}