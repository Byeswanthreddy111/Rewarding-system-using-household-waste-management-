import React, { useState } from 'react';
import { WasteData } from '../types/waste';
import { Leaf, Recycle, Trash2, Award, Save } from 'lucide-react';

interface WasteInputFormProps {
  onAddWaste: (newWaste: WasteData) => void;
}

export function WasteInputForm({ onAddWaste }: WasteInputFormProps) {
  const [bioWaste, setBioWaste] = useState<number>(0);
  const [recyclableWaste, setRecyclableWaste] = useState<number>(0);
  const [nonRecyclableWaste, setNonRecyclableWaste] = useState<number>(0);
  const [calculatedReward, setCalculatedReward] = useState<number | null>(null);
  const [isPreview, setIsPreview] = useState(false);

  const calculateReward = (bio: number, recyclable: number, nonRecyclable: number): number => {
    const term1 = bio * 0.2 * 60;
    const term2 = recyclable * 7;
    const term3 = nonRecyclable * 4;
    const term4 = (bio + recyclable + nonRecyclable) * 2;
    const term5 = bio * 4;
    const term6 = recyclable * 2;
    
    return Number((term1 + term2 - term3 - (term4 + term5 + term6)).toFixed(2));
  };

  const handlePreview = () => {
    const reward = calculateReward(bioWaste, recyclableWaste, nonRecyclableWaste);
    setCalculatedReward(reward);
    setIsPreview(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (bioWaste === 0 && recyclableWaste === 0 && nonRecyclableWaste === 0) {
      return; // Don't submit if all values are 0
    }
    
    const reward = calculateReward(bioWaste, recyclableWaste, nonRecyclableWaste);
    
    const newWaste: WasteData = {
      bioWaste,
      recyclableWaste,
      nonRecyclableWaste,
      reward,
      date: new Date().toISOString()
    };
    
    onAddWaste(newWaste);
    
    // Reset form
    setBioWaste(0);
    setRecyclableWaste(0);
    setNonRecyclableWaste(0);
    setCalculatedReward(null);
    setIsPreview(false);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Record Waste</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
              <Leaf className="w-4 h-4 text-green-600 mr-1" />
              Bio Waste (kg)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={bioWaste}
              onChange={(e) => setBioWaste(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            />
          </div>
          
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
              <Recycle className="w-4 h-4 text-blue-600 mr-1" />
              Recyclable Waste (kg)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={recyclableWaste}
              onChange={(e) => setRecyclableWaste(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
              <Trash2 className="w-4 h-4 text-red-600 mr-1" />
              Non-Recyclable Waste (kg)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={nonRecyclableWaste}
              onChange={(e) => setNonRecyclableWaste(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500"
            />
          </div>
          
          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={handlePreview}
              className="flex-1 bg-gray-100 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-1"
            >
              <Award className="w-4 h-4" />
              Preview Reward
            </button>
            
            <button
              type="submit"
              className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-1"
            >
              <Save className="w-4 h-4" />
              Save Record
            </button>
          </div>
        </div>
      </form>
      
      {isPreview && calculatedReward !== null && (
        <div className={`mt-4 p-4 rounded-lg ${calculatedReward >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
          <h3 className="font-medium flex items-center gap-1">
            <Award className={`w-5 h-5 ${calculatedReward >= 0 ? 'text-green-600' : 'text-red-600'}`} />
            Estimated Reward
          </h3>
          <p className={`text-2xl font-bold ${calculatedReward >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {calculatedReward.toFixed(2)} points
          </p>
          
          {calculatedReward < 0 && (
            <p className="text-sm text-red-600 mt-1">
              Your non-recyclable waste is too high compared to your recyclable waste.
              Try to reduce non-recyclable waste to earn positive rewards.
            </p>
          )}
        </div>
      )}
    </div>
  );
}