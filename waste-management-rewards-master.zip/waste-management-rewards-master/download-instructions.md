# Files to Download for VS Code

## Project Structure
Here's a list of all files needed to run the Waste Management Rewards application:

### Configuration Files
- `package.json` - Dependencies and scripts
- `package-lock.json` - Dependency lock file
- `tsconfig.json` - TypeScript configuration
- `tsconfig.app.json` - App-specific TypeScript configuration
- `tsconfig.node.json` - Node-specific TypeScript configuration
- `vite.config.ts` - Vite configuration
- `eslint.config.js` - ESLint configuration
- `postcss.config.js` - PostCSS configuration
- `tailwind.config.js` - Tailwind CSS configuration

### HTML
- `index.html` - Main HTML file

### CSS
- `src/index.css` - Main CSS file with Tailwind imports

### TypeScript Definitions
- `src/vite-env.d.ts` - Vite environment type definitions
- `src/types/waste.ts` - Waste data type definitions

### Main Application Files
- `src/main.tsx` - Application entry point
- `src/App.tsx` - Main application component

### Components
- `src/components/DateFilter.tsx` - Date filtering component
- `src/components/HistoricalDataTable.tsx` - Table for historical data
- `src/components/TimeSeriesCharts.tsx` - Charts for time series analysis

### Data and Models
- `src/data/sampleData.ts` - Sample waste data generator
- `src/models/RandomForestModel.ts` - AI prediction model

### Utilities
- `src/utils/dateUtils.ts` - Date utility functions
- `src/utils/timeSeriesUtils.ts` - Time series aggregation utilities

## Running the Application
1. Clone or download all files maintaining the directory structure
2. Open the project folder in VS Code
3. Run `npm install` to install dependencies
4. Run `npm run dev` to start the development server