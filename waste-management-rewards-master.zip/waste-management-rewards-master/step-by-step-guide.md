# Step-by-Step Guide to Setting Up the Waste Management Rewards Project

This guide will walk you through the process of setting up the Waste Management Rewards project in VS Code, from creating the directory structure to running the application.

## Prerequisites

- Node.js and npm installed on your computer
- Visual Studio Code installed
- Basic familiarity with the command line

## Step 1: Create the Project Directory

1. Open File Explorer (Windows) or Finder (Mac)
2. Navigate to where you want to create the project (e.g., Desktop)
3. Create a new folder named `waste-management-rewards`

## Step 2: Set Up the Directory Structure

1. Open the `waste-management-rewards` folder
2. Create the following subdirectories:
   - `src`
   - `src/components`
   - `src/data`
   - `src/models`
   - `src/types`
   - `src/utils`

## Step 3: Create Configuration Files

First, let's create the configuration files in the root directory:

1. Open VS Code
2. Go to File > Open Folder and select your `waste-management-rewards` folder
3. Create the following files in the root directory:
   - `package.json`
   - `eslint.config.js`
   - `index.html`
   - `postcss.config.js`
   - `tailwind.config.js`
   - `tsconfig.json`
   - `tsconfig.app.json`
   - `tsconfig.node.json`
   - `vite.config.ts`

Copy the content for each file from the "File Contents Guide".

## Step 4: Create Source Files

Now, let's create the main source files:

1. Create `src/index.css`
2. Create `src/main.tsx`
3. Create `src/App.tsx`
4. Create `src/vite-env.d.ts`

Copy the content for each file from the "File Contents Guide".

## Step 5: Create Component Files

Create the following component files in the `src/components` directory:

1. `DateFilter.tsx`
2. `HistoricalDataTable.tsx`
3. `TimeSeriesCharts.tsx`
4. `WasteInputForm.tsx`
5. `RewardDistribution.tsx`
6. `FuturePredictions.tsx`
7. `QuickAddWaste.tsx`
8. `ModelAccuracyDisplay.tsx`

Copy the content for each file from the "File Contents Guide".

## Step 6: Create Data, Model, Type, and Utility Files

1. Create `src/data/sampleData.ts`
2. Create `src/models/RandomForestModel.ts`
3. Create `src/types/waste.ts`
4. Create `src/utils/dateUtils.ts`
5. Create `src/utils/timeSeriesUtils.ts`

Copy the content for each file from the "File Contents Guide".

## Step 7: Install Dependencies

1. Open a terminal in VS Code (Terminal > New Terminal)
2. Run the following command to install all dependencies:
   ```
   npm install
   ```
3. Wait for the installation to complete

## Step 8: Run the Application

1. In the terminal, run:
   ```
   npm run dev
   ```
2. The application should start and display a URL (usually http://localhost:5173)
3. Open this URL in your browser to view the application

## Troubleshooting

### Package.json Not Found
If you see an error about package.json not being found:
1. Check that you're in the correct directory
2. Run `pwd` (Mac/Linux) or `cd` (Windows) to see your current directory
3. Make sure it shows the path to your project root

### Module Not Found Errors
If you see errors about modules not being found:
1. Make sure you've run `npm install`
2. Check that all files are in the correct locations
3. Verify that your package.json contains all the required dependencies

### Port Already in Use
If port 5173 is already in use:
1. You can either close the application using that port
2. Or modify the vite.config.ts file to use a different port:
   ```typescript
   export default defineConfig({
     plugins: [react()],
     server: {
       port: 3000 // Change to any available port
     }
   });
   ```

## Next Steps

Once the application is running:
1. Explore the different tabs in the application
2. Try adding new waste records
3. Generate predictions using the AI model
4. Analyze the historical data and charts