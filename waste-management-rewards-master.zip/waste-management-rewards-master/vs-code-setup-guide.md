# Running the Waste Management Rewards Project in VS Code

This guide will walk you through setting up and running the Waste Management Rewards project in Visual Studio Code.

## Prerequisites

- [Node.js](https://nodejs.org/) (v16 or newer)
- [Visual Studio Code](https://code.visualstudio.com/)
- [Git](https://git-scm.com/) (optional, for version control)

## Step 1: Set Up the Project

1. **Create a project folder**:
   - Create a new folder named `waste-management-rewards` on your computer

2. **Open VS Code**:
   - Launch Visual Studio Code
   - Go to `File > Open Folder` and select your `waste-management-rewards` folder

3. **Create the folder structure**:
   - In VS Code, create the following folder structure:
   ```
   waste-management-rewards/
   ├── src/
   │   ├── components/
   │   ├── data/
   │   ├── models/
   │   ├── types/
   │   └── utils/
   ```

## Step 2: Create Configuration Files

Create the following configuration files in the root directory:

1. **package.json** - For dependencies and scripts
2. **eslint.config.js** - ESLint configuration
3. **index.html** - Main HTML file
4. **postcss.config.js** - PostCSS configuration
5. **tailwind.config.js** - Tailwind CSS configuration
6. **tsconfig.json** - TypeScript configuration
7. **tsconfig.app.json** - App-specific TypeScript configuration
8. **tsconfig.node.json** - Node-specific TypeScript configuration
9. **vite.config.ts** - Vite configuration

Copy the content for each file from the project files provided.

## Step 3: Create Source Files

Create the following source files:

1. **src/index.css** - Main CSS file
2. **src/main.tsx** - Application entry point
3. **src/App.tsx** - Main application component
4. **src/vite-env.d.ts** - Vite environment type definitions

## Step 4: Create Component Files

Create the following component files in the `src/components` directory:

1. **DateFilter.tsx** - Date filtering component
2. **HistoricalDataTable.tsx** - Table for historical data
3. **TimeSeriesCharts.tsx** - Charts for time series analysis
4. **WasteInputForm.tsx** - Form for adding waste data
5. **RewardDistribution.tsx** - Reward distribution analysis
6. **FuturePredictions.tsx** - AI predictions component
7. **QuickAddWaste.tsx** - Quick add waste component

## Step 5: Create Data, Model, Type, and Utility Files

Create the following files:

1. **src/data/sampleData.ts** - Sample waste data
2. **src/models/RandomForestModel.ts** - AI prediction model
3. **src/types/waste.ts** - Type definitions
4. **src/utils/dateUtils.ts** - Date utility functions
5. **src/utils/timeSeriesUtils.ts** - Time series aggregation utilities

## Step 6: Install Dependencies and Run the Project

1. **Open the Terminal in VS Code**:
   - Go to `Terminal > New Terminal`

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start the development server**:
   ```bash
   npm run dev
   ```

4. **View the application**:
   - The terminal will show a URL (usually http://localhost:5173)
   - VS Code may prompt you to open the URL in a browser
   - Alternatively, you can manually open the URL in your browser

## Troubleshooting

### Port Already in Use
If port 5173 is already in use:
```bash
# Kill the process using the port (on Windows)
netstat -ano | findstr :5173
taskkill /PID <PID> /F

# Kill the process using the port (on macOS/Linux)
lsof -i :5173
kill -9 <PID>
```

### Module Not Found Errors
If you see errors about modules not being found:
- Make sure you've run `npm install`
- Check that all files are in the correct locations
- Verify that your package.json contains all the required dependencies

## VS Code Extensions for Better Development Experience

Install these VS Code extensions for a better development experience:

1. **ESLint** - For linting
2. **Prettier** - For code formatting
3. **Tailwind CSS IntelliSense** - For Tailwind CSS class suggestions
4. **JavaScript and TypeScript Nightly** - For better TypeScript support
5. **ES7+ React/Redux/React-Native snippets** - For React snippets

To install extensions, click on the Extensions icon in the Activity Bar on the side of VS Code or press `Ctrl+Shift+X` (`Cmd+Shift+X` on macOS), then search for and install each extension.