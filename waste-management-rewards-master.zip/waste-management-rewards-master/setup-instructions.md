# Setup Instructions for Waste Management Rewards Project

## Step 1: Create Project Directory
First, create a proper directory for your project:

1. Open File Explorer
2. Navigate to a location where you want to store the project (e.g., Desktop)
3. Create a new folder named "waste-management-rewards"

## Step 2: Download Project Files
Download all the project files maintaining the directory structure:

1. Create the following folder structure in your project directory:
   ```
   waste-management-rewards/
   ├── src/
   │   ├── components/
   │   ├── data/
   │   ├── models/
   │   ├── types/
   │   └── utils/
   ```

2. Download each file from the project into its corresponding location.

## Step 3: Run the Project
Once all files are in place:

1. Open VS Code
2. Choose "File > Open Folder" and select your "waste-management-rewards" folder
3. Open a terminal in VS Code (Terminal > New Terminal)
4. Run the following commands:
   ```
   npm install
   npm run dev
   ```

## Common Issues

### "package.json not found" Error
If you see this error, it means you're running npm commands in the wrong directory. Make sure:
- You've downloaded the package.json file to your project root
- Your terminal is open to the correct project directory
- You're not in a subdirectory of your project

### Checking Your Current Directory
In the terminal, you can check your current directory with:
- Windows: `cd`
- Mac/Linux: `pwd`

Make sure it shows the path to your project root where package.json is located.